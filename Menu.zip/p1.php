<!doctype html>
<html>
          <head>
                   <meta charset="utf-8">
                   <link rel="stylesheet" href="menu_styles.css">
                    <title>Projekt</title>
          </head>
          <body>
<?php 
                    $curpage = 'p1.php';
                    include 'menu.php'; ?>
          <h1>Page 1</h1>
                  <p>Page 1 txt bla bla</p>
<?php include 'footer.php'; ?>