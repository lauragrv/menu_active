<!doctype html>
<html>
          <head>
                   <meta charset="utf-8">
                   <link rel="stylesheet" href="menu_styles.css">
                    <title>Projekt</title>
          </head>
          <body>
                  <?php 
                     $curpage = 'p3.php';
                    include 'menu.php'; ?>
          <h1>Page 3</h1>
                  <p>Page 3 txt bla bla</p>
<?php include 'footer.php'; ?>