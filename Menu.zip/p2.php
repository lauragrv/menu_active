<!doctype html>
<html>
          <head>
                   <meta charset="utf-8">
                   <link rel="stylesheet" href="menu_styles.css">
                    <title>Projekt</title>
          </head>
          <body>
                  <?php 
                    $curpage = 'p2.php';
                    include 'menu.php'; ?>
          <h1>Page 2</h1>
                  <p>Page 2 txt bla bla</p>
<?php include 'footer.php'; ?>